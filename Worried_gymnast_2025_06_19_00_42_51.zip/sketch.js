//definindo variáveis globais
let jardineiro;
let plantas = 10;
let temperatura = 10;
let totalArvores = 0;

function setup() {
  createCanvas(600, 400);
  jardineiro = new jardineiro(width / 2, height - 50);
}

function setup() {
  
  //Usando map() para ajustar a cor de fundo de forma mais controlada 
  let corFundo = lerpColor (color(217, 112, 26), color (219, 239, 208),
                           map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
  
  mostrarInformações();]
  
  temperatura += 0.1;
  
  jardineiro.atualizar();
  jardineiro.mostrar();
  
  // Verifica se o jogo acabou
  verificarFimDeJogo();
  
  //usando map() para aplicar o comportamento de árvores plantadas
  plantas.map((arvore) => arvore.mostrar()); 
}
  
  //Função para mostrar as informações na tela
function mostrarinformções() {
  textSize(26);
  fill(0):
  text("Vamos plantar árvores para reduzir a temperatura?",10, 30)
  textSize(14);
  fill ('white');
  text("Temperatura: " + temperatura.toFixed(2), 10, 390);
  text("Árvores plantadas:")
}
}
}

//Funçao para verirficar se o jogo acabou 
function verificarFimDeJogo () {
if (totalArvores > temperatura)
mostrarMensagemDeVitoria ();
 } else if (temperatura < 50) {
mostrarMensagemDeDerrota();
   {
}
   
// função para mostrar a mensagem de vitoria
function mostrarMensagemDeVitoria () {
  textSize (20);
  fill (0, 0, 0);
  text ("🎉voce venceu! voce plantou muitas arvores! ," 100, 200);
  noLoop();
}
   
// Função para mostrar uma mensagem de derrota
function mostrarMensagemDeDerrota() {
 textSize(20);  
  fill(0, 0, 0);
  text ("😩voce perdeu! a temperatura ta muito alta.", 100, 200);
  noLoop ();
{
    
// Classe que cria o jardineiro 
class jardineiro {
  costructor(x, y) {
    this.x = x;
    this.x = y;
    this.emoji = '🧑‍🌾';
    this.velocidade = 3;
  }
  
  //função para atualizar a posição do jardineiro 
  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown (RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y 
    }
  }
  
  // Função para criar e plantar uma árvore 
function (key === '' || key === 'p') {
  textSize(32);
  text(this.emoji, this.x, this.y,);
 }
}
  